const form = document.querySelector("#presenceForm");
const stopButton = document.querySelector("#stopButton");
const siteButton = document.querySelector("#siteButton");
const statusLabel = document.querySelector("#status");

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const payload = {
    reference: document.querySelector("#reference").value.trim(),
    phase: document.querySelector("#phase").value,
    progress: document.querySelector("#progress").value.trim() || "Tracking project",
  };

  try {
    await window.thunderCompanion.startPresence(payload);
    statusLabel.textContent = "Rich Presence is running in Discord.";
  } catch (error) {
    statusLabel.textContent = `Could not start Rich Presence: ${error.message}`;
  }
});

stopButton.addEventListener("click", async () => {
  await window.thunderCompanion.stopPresence();
  statusLabel.textContent = "Rich Presence stopped.";
});

siteButton.addEventListener("click", () => {
  window.thunderCompanion.openSite();
});
