const { app, BrowserWindow, Tray, Menu, ipcMain, shell } = require("electron");
const path = require("path");
const RPC = require("discord-rpc");

const siteUrl = "https://fleettest-production.up.railway.app";
const clientId = process.env.DISCORD_APPLICATION_ID || "REPLACE_WITH_DISCORD_APPLICATION_ID";

let mainWindow;
let tray;
let rpc;
let currentPresence = null;

function createWindow() {
  if (mainWindow) {
    mainWindow.show();
    mainWindow.focus();
    return;
  }

  mainWindow = new BrowserWindow({
    width: 520,
    height: 680,
    title: "Thunder Buddies Companion",
    icon: path.join(__dirname, "icon.png"),
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
    },
  });

  mainWindow.loadFile("renderer.html");
  mainWindow.on("closed", () => {
    mainWindow = null;
  });
}

async function connectRpc() {
  if (rpc) return rpc;

  RPC.register(clientId);
  rpc = new RPC.Client({ transport: "ipc" });

  rpc.on("ready", () => {
    if (currentPresence) setPresence(currentPresence);
  });

  await rpc.login({ clientId });
  return rpc;
}

async function setPresence(payload) {
  currentPresence = payload;
  const client = await connectRpc();
  const reference = payload.reference || "Studio Dashboard";
  const phase = payload.phase || "Tracking progress";
  const progress = payload.progress || "Live project";

  await client.setActivity({
    details: `Tracking ${reference}`,
    state: `${phase} | ${progress}`,
    startTimestamp: Date.now(),
    largeImageKey: "thunderbuddies_logo",
    largeImageText: "Thunder Buddies Studios",
    buttons: [
      {
        label: "Open Dashboard",
        url: payload.url || siteUrl,
      },
    ],
  });
}

function clearPresence() {
  if (!rpc) return;
  rpc.clearActivity();
  rpc.destroy();
  rpc = null;
  currentPresence = null;
}

function createTray() {
  tray = new Tray(path.join(__dirname, "icon.png"));
  tray.setToolTip("Thunder Buddies Companion");
  tray.setContextMenu(
    Menu.buildFromTemplate([
      { label: "Open Companion", click: createWindow },
      { label: "Open Website", click: () => shell.openExternal(siteUrl) },
      { label: "Stop Rich Presence", click: clearPresence },
      { type: "separator" },
      { label: "Quit", click: () => app.quit() },
    ])
  );
}

ipcMain.handle("presence:start", async (_event, payload) => {
  await setPresence({
    ...payload,
    url: payload.reference ? `${siteUrl}/requests/${encodeURIComponent(payload.reference)}` : siteUrl,
  });
  return { ok: true };
});

ipcMain.handle("presence:stop", () => {
  clearPresence();
  return { ok: true };
});

ipcMain.handle("site:open", () => {
  shell.openExternal(siteUrl);
  return { ok: true };
});

app.whenReady().then(() => {
  createWindow();
  createTray();
});

app.on("before-quit", clearPresence);

app.on("window-all-closed", (event) => {
  event.preventDefault();
});
